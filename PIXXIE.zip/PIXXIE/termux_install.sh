#!/bin/bash
# Direct install for Termux — no pip, no external deps
echo ""
echo "    PIXXIE — DEM NO GO TELL U"
echo "    Creator: Raphael"
echo ""

mkdir -p $HOME/PIXXIE
cd $HOME/PIXXIE

pkg update -y
pkg install -y python git curl wget

chmod +x pixxie.py
chmod +x modules/*.py
chmod +x core/*.py

cat > $PREFIX/bin/pixxie << 'EOF'
#!/bin/bash
cd $HOME/PIXXIE && python3 pixxie.py "$@"
EOF
chmod +x $PREFIX/bin/pixxie

python3 -c "
words = [
    'password', '123456', '12345678', 'qwerty', 'abc123', 'monkey', 'letmein',
    'dragon', '111111', 'baseball', 'iloveyou', 'trustno1', 'sunshine',
    'princess', 'admin', 'welcome', 'shadow', 'ashley', 'football', 'jesus',
    'michael', 'ninja', 'mustang', 'password1', '123456789', 'adobe123',
    'admin123', 'root', 'toor', 'ubuntu', 'termux', 'raspberry', 'hacker',
    '1234567', '1234567890', 'password123', 'login', 'master', 'photoshop',
    '1q2w3e4r', 'zaq12wsx', 'qwertyuiop', 'lovely', 'whatever', 'starwars',
    '123123', '654321', 'superman', 'batman', 'spiderman', 'harley',
    'hannah', 'daniel', 'jordan', 'maggie', 'buster', 'thomas', 'robert',
    'george', 'joshua', 'matthew', 'andrew', 'tigger', 'sunshine', 'iloveyou',
    '2000', 'charlie', 'robert', 'thomas', 'hockey', 'ranger', 'mike',
    'jordan', 'maggie', 'buster', 'daniel', 'andrew', 'joshua', 'pepper',
    'ginger', 'taylor', 'austin', 'william', 'martin', 'chelsea', 'oliver',
    'purple', 'silver', 'cookie', 'bandit', 'buster', 'ranger', 'thunder',
    'shadow', 'rocket', 'falcon', 'eagle', 'cobra', 'viper', 'panther',
    'tiger', 'lion', 'wolf', 'bear', 'shark', 'dragon', 'phoenix'
]
with open('wordlists/worldlist.txt', 'w') as f:
    f.write('\n'.join(words))
print(f'Generated {len(words)} passwords')
"

echo ""
echo "[+] PIXXIE ready!"
echo "[+] Password: meme"
echo ""
echo "Run: pixxie"
echo "Or:  cd ~/PIXXIE && python3 pixxie.py"
echo ""
echo "DEM NO GO TELL U"
