#!/usr/bin/env python3
import sys
import os
import importlib

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "core"))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "modules"))

from utils import clear, banner

MODULES = {
    "1": ("Man In The Middle", "mitm", "run_mitm"),
    "2": ("Phishing Suite", "phisher", "run_phisher"),
    "3": ("URL Cloner", "cloner", "run_cloner"),
    "4": ("OSINT & Recon", "recon", "run_recon"),
    "5": ("Brute Force Cracker", "brute", "run_brute"),
    "6": ("Location Tracker", "tracker", "run_tracker"),
    "7": ("Backdoor Planter", "backdoor", "run_backdoor"),
    "8": ("Custom Malware Builder", "malware", "run_malware"),
    "9": ("Game Phishing (CODM)", "game_phish", "run_game_phish"),
    "10": ("Social Media Ban Tool", "banner_mod", "run_banner"),
    "11": ("WiFi Hacking Suite", "wifi", "run_wifi"),
    "12": ("SEO Poisoning", "seo", "run_seo"),
    "13": ("DoS / DDoS Cannon", "dos", "run_dos"),
    "14": ("Multi-Platform Payloads", "payload", "run_payload"),
    "15": ("Bugging / Surveillance", "bug", "run_bug"),
    "16": ("SQL Injection", "sqli", "run_sqli"),
    "17": ("Social Media Crasher", "crasher", "run_crasher"),
    "18": ("Device Info Stealer", "stealer", "run_stealer"),
    "19": ("Payment Portal", "payment", "run_payment"),
    "0": ("Exit PIXXIE", None, None),
}

def lazy_import(mod_name, func_name):
    try:
        mod = importlib.import_module(mod_name)
        return getattr(mod, func_name)
    except ImportError as e:
        print("\n[PIXXIE] Missing dependency: " + str(e))
        print("[PIXXIE] Install: pkg install python-requests python-beautifulsoup4")
        return None
    except Exception as e:
        print("\n[PIXXIE] Module error: " + str(e))
        return None

def main():
    clear()
    banner()
    while True:
        print("\n    ╔═══════════════════════════════════════════════════════╗")
        print("    ║              PIXXIE COMMAND CENTER                    ║")
        print("    ╠═══════════════════════════════════════════════════════╣")
        for key, (name, _, _) in MODULES.items():
            print("    ║  [" + key + "] " + name.ljust(45) + " ║")
        print("    ╚═══════════════════════════════════════════════════════╝")
        choice = input("\n[PIXXIE] Select module: ").strip()
        if choice == "0":
            print("\n[PIXXIE] Going dark. DEM NO GO TELL U.")
            break
        if choice in MODULES:
            name, mod, func = MODULES[choice]
            if mod is None:
                continue
            print("\n[PIXXIE] Loading " + name + "...")
            run_func = lazy_import(mod, func)
            if run_func is None:
                continue
            try:
                run_func()
            except KeyboardInterrupt:
                print("\n[PIXXIE] Interrupted.")
            except Exception as e:
                print("[PIXXIE] Error: " + str(e))
        else:
            print("[PIXXIE] Invalid selection.")

if __name__ == "__main__":
    main()
