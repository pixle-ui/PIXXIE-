#!/usr/bin/env python3
import sys
import os

def verify_password():
    try:
        import getpass
        pwd = getpass.getpass("[PIXXIE] Enter command password: ")
    except Exception:
        pwd = input("[PIXXIE] Enter command password (visible): ")
    if pwd.strip().lower() != "meme":
        print("[PIXXIE] ACCESS DENIED.")
        sys.exit(1)
    print("[PIXXIE] ACCESS GRANTED. Welcome back, Raphael.")
    return True

def auth_required(func):
    def wrapper(*args, **kwargs):
        verify_password()
        return func(*args, **kwargs)
    return wrapper
