#!/usr/bin/env python3
import os
import random
import string
from datetime import datetime

def clear():
    os.system("clear")

def banner():
    print("""
    ██████╗ ██╗██╗  ██╗██╗  ██╗██╗███████╗
    ██╔══██╗██║╚██╗██╔╝╚██╗██╔╝██║██╔════╝
    ██████╔╝██║ ╚███╔╝  ╚███╔╝ ██║█████╗  
    ██╔═══╝ ██║ ██╔██╗  ██╔██╗ ██║██╔══╝  
    ██║     ██║██╔╝ ██╗██╔╝ ██╗██║███████╗
    ╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚══════╝

    ╔═══════════════════════════════════════╗
    ║  SLOGAN: DEM NO GO TELL U             ║
    ║  CREATOR: Raphael                     ║
    ║  BANK: Opay                           ║
    ║  NAME: Okolie Raphael Chinemerem      ║
    ╚═══════════════════════════════════════╝
    """)

def log_action(module, action, status="OK"):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entry = "[" + timestamp + "] [" + module + "] " + action + " | Status: " + status + "\n"
    log_path = os.path.join(os.path.dirname(__file__), "..", "logs", "pixxie_ops.log")
    with open(log_path, "a") as f:
        f.write(log_entry)

def random_string(length=12):
    return "".join(random.choices(string.ascii_letters + string.digits, k=length))
