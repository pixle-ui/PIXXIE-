#!/bin/bash
echo ""
echo "    ██████╗ ██╗██╗  ██╗██╗  ██╗██╗███████╗"
echo "    ██╔══██╗██║╚██╗██╔╝╚██╗██╔╝██║██╔════╝"
echo "    ██████╔╝██║ ╚███╔╝  ╚███╔╝ ██║█████╗  "
echo "    ██╔═══╝ ██║ ██╔██╗  ██╔██╗ ██║██╔══╝  "
echo "    ██║     ██║██╔╝ ██╗██╔╝ ██╗██║███████╗"
echo "    ╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚══════╝"
echo ""
echo "    DEM NO GO TELL U"
echo "    Creator: Raphael"
echo ""

# Install deps (Termux-safe, no pip if blocked)
if [ -n "$TERMUX_VERSION" ]; then
    echo "[*] Termux detected"
    pkg update -y
    pkg install -y python git curl wget
else
    echo "[*] Linux detected"
    apt-get update -y 2>/dev/null || true
    apt-get install -y python3 python3-pip git curl wget 2>/dev/null || true
fi

# Try pip, but don't fail if blocked
echo "[*] Installing Python packages (safe mode)..."
pip3 install --upgrade pip 2>/dev/null || echo "[!] pip upgrade blocked, continuing..."
pip3 install requests beautifulsoup4 phonenumbers pynput pyautogui opencv-python sounddevice wavio 2>/dev/null || echo "[!] Some packages blocked by Termux, tool works without them"

# Set permissions
echo "[*] Setting permissions..."
chmod +x pixxie.py
chmod +x modules/*.py
chmod +x core/*.py

# Create launcher
cat > pixxie << 'EOF'
#!/bin/bash
cd "$(dirname "$0")"
python3 pixxie.py "$@"
EOF
chmod +x pixxie

# Add to PATH
if [ -d "$HOME/.local/bin" ]; then
    cp pixxie "$HOME/.local/bin/" 2>/dev/null || true
fi

# Generate wordlist
echo "[*] Generating wordlist..."
python3 -c "
words = [
    'password', '123456', '12345678', 'qwerty', 'abc123', 'monkey', 'letmein',
    'dragon', '111111', 'baseball', 'iloveyou', 'trustno1', 'sunshine',
    'princess', 'admin', 'welcome', 'shadow', 'ashley', 'football', 'jesus',
    'michael', 'ninja', 'mustang', 'password1', '123456789', 'adobe123',
    'admin123', 'root', 'toor', 'ubuntu', 'termux', 'raspberry', 'hacker',
    '1234567', '1234567890', 'password123', 'login', 'master', 'photoshop',
    '1q2w3e4r', 'zaq12wsx', 'qwertyuiop', 'lovely', 'whatever', 'starwars',
    '123123', '654321', 'superman', 'batman', 'spiderman', 'harley',
    'hannah', 'daniel', 'jordan', 'maggie', 'buster', 'thomas', 'robert',
    'george', 'joshua', 'matthew', 'andrew', 'tigger', 'sunshine', 'iloveyou',
    '2000', 'charlie', 'robert', 'thomas', 'hockey', 'ranger', 'mike',
    'jordan', 'maggie', 'buster', 'daniel', 'andrew', 'joshua', 'pepper',
    'ginger', 'taylor', 'austin', 'william', 'martin', 'chelsea', 'oliver',
    'purple', 'silver', 'cookie', 'bandit', 'buster', 'ranger', 'thunder',
    'shadow', 'rocket', 'falcon', 'eagle', 'cobra', 'viper', 'panther',
    'tiger', 'lion', 'wolf', 'bear', 'shark', 'dragon', 'phoenix'
]
with open('wordlists/worldlist.txt', 'w') as f:
    f.write('\n'.join(words))
print(f'Generated {len(words)} passwords')
"

echo ""
echo "[+] PIXXIE installed!"
echo "[+] Password: meme"
echo ""
echo "Run: ./pixxie"
echo "Or:  python3 pixxie.py"
echo ""
echo "DEM NO GO TELL U"
