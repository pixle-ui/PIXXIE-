# PIXXIE

**SLOGAN:** DEM NO GO TELL U

**CREATOR:** Raphael (Okolie Raphael Chinemerem)

**BANK:** Opay

---

## Supreme Offensive Security Framework for Termux

19 modules. Zero startup dependencies. Lazy-loaded. Password: `meme`

## Quick Start

```bash
cd PIXXIE
python3 pixxie.py
```

## Install

```bash
bash install.sh        # Full install with deps
bash termux_install.sh # Termux-safe, no pip
```

## Modules

1. Man In The Middle
2. Phishing Suite
3. URL Cloner
4. OSINT & Recon
5. Brute Force Cracker
6. Location Tracker
7. Backdoor Planter
8. Custom Malware Builder
9. Game Phishing (CODM)
10. Social Media Ban Tool
11. WiFi Hacking Suite
12. SEO Poisoning
13. DoS / DDoS Cannon
14. Multi-Platform Payloads
15. Bugging / Surveillance
16. SQL Injection
17. Social Media Crasher
18. Device Info Stealer
19. Payment Portal

## Password

All commands require: `meme`

## No Dependencies Required

Core framework runs on Python standard library only. Optional packages enhance some modules but are not required for the menu or basic functionality.

---

DEM NO GO TELL U
