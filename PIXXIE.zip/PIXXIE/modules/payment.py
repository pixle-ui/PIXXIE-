#!/usr/bin/env python3
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "core"))
from auth import auth_required
from utils import log_action

@auth_required
def run_payment():
    print("""
    ╔═══════════════════════════════════════════════════════╗
    ║           PAYMENT PORTAL MODULE                       ║
    ╚═══════════════════════════════════════════════════════╝
    """)
    print("[1] View Payment Details")
    print("[2] Set Custom Price")
    print("[3] Generate Payment Request")
    print("[4] Verify Payment")
    choice = input("\n[PAYMENT] Select: ").strip()
    bank = "Opay"
    name = "Okolie Raphael Chinemerem"
    if choice == "1":
        print("""
    ╔═══════════════════════════════════════════════════════╗
    ║              PAYMENT INFORMATION                      ║
    ╠═══════════════════════════════════════════════════════╣
    ║  BANK:      Opay                                    ║
    ║  NAME:      Okolie Raphael Chinemerem               ║
    ║  CREATOR:   Raphael                                 ║
    ║  TOOL:      PIXXIE — DEM NO GO TELL U               ║
    ╚═══════════════════════════════════════════════════════╝
        """)
        log_action("PAYMENT", "Details viewed")
    elif choice == "2":
        price = input("[PAYMENT] Price (NGN): ").strip()
        print("    AMOUNT:    NGN " + price)
        print("    BANK:      " + bank)
        print("    NAME:      " + name)
        print("    Send proof to Raphael")
        log_action("PAYMENT", "Price set: " + price)
    elif choice == "3":
        service = input("[PAYMENT] Service: ").strip()
        amount = input("[PAYMENT] Amount (NGN): ").strip()
        req_id = "PIXXIE-" + os.urandom(4).hex().upper()
        print("    REQUEST:   " + req_id)
        print("    SERVICE:   " + service)
        print("    AMOUNT:    NGN " + amount)
        print("    BANK:      " + bank)
        print("    NAME:      " + name)
        with open("payment_" + req_id + ".txt", "w") as f:
            f.write("ID: " + req_id + "\n")
            f.write("Service: " + service + "\n")
            f.write("Amount: NGN " + amount + "\n")
            f.write("Bank: " + bank + "\n")
            f.write("Name: " + name + "\n")
        log_action("PAYMENT", "Request: " + req_id)
    elif choice == "4":
        tx = input("[PAYMENT] Transaction ID: ").strip()
        print("[PAYMENT] Verifying " + tx + "...")
        print("[PAYMENT] Contact Raphael with proof")
        log_action("PAYMENT", "Verify: " + tx)
