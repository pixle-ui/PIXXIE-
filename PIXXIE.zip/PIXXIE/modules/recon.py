#!/usr/bin/env python3
import sys, os, subprocess, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "core"))
from auth import auth_required
from utils import log_action

@auth_required
def run_recon():
    print("""
    ╔═══════════════════════════════════════════════════════╗
    ║           OSINT & RECONNAISSANCE MODULE               ║
    ╚═══════════════════════════════════════════════════════╝
    """)
    print("[1] Sherlock — Username Search")
    print("[2] Nmap — Network Scanner")
    print("[3] Holehe — Email OSINT")
    print("[4] DNS Enumeration")
    print("[5] WHOIS Lookup")
    print("[6] Subdomain Brute Force")
    print("[7] Full Recon Report")
    choice = input("\n[RECON] Select: ").strip()
    if choice == "1":
        username = input("[RECON] Username to hunt: ").strip()
        print("[RECON] Launching Sherlock on '" + username + "'...")
        print("[RECON] Install: pip install sherlock-project")
        print("[RECON] (Running built-in stub)\n")
        sites = [
            ("Instagram", "https://www.instagram.com/" + username),
            ("Twitter/X", "https://twitter.com/" + username),
            ("GitHub", "https://github.com/" + username),
            ("Reddit", "https://www.reddit.com/user/" + username),
            ("TikTok", "https://www.tiktok.com/@" + username),
            ("Facebook", "https://www.facebook.com/" + username),
            ("YouTube", "https://www.youtube.com/@" + username),
            ("LinkedIn", "https://www.linkedin.com/in/" + username),
            ("Pinterest", "https://www.pinterest.com/" + username),
            ("Twitch", "https://www.twitch.tv/" + username),
            ("Spotify", "https://open.spotify.com/user/" + username),
            ("GitLab", "https://gitlab.com/" + username),
            ("Medium", "https://medium.com/@" + username),
            ("Dev.to", "https://dev.to/" + username),
            ("Quora", "https://www.quora.com/profile/" + username)
        ]
        results = []
        print("[RECON] ========== SHERLOCK RESULTS ==========")
        for site_name, site_url in sites:
            result = {"site": site_name, "url": site_url, "status": "check_manually"}
            results.append(result)
            print("[RECON] [+] " + site_name.ljust(15) + " | " + site_url)
        print("[RECON] =====================================")
        print("[RECON] Total sites checked: " + str(len(results)))
        filename = username + "_sherlock.json"
        with open(filename, "w") as f:
            json.dump(results, f, indent=2)
        print("[RECON] Results saved to " + filename)
        log_action("RECON", "Sherlock on " + username + ", " + str(len(results)) + " sites")
    elif choice == "2":
        target = input("[RECON] Target IP/Domain: ").strip()
        scan_type = input("[RECON] Scan type (quick/deep/vuln): ").strip() or "quick"
        cmds = {
            "quick": "nmap -sV -O " + target,
            "deep": "nmap -sS -sV -O -A -p- " + target,
            "vuln": "nmap --script vuln " + target
        }
        cmd = cmds.get(scan_type, cmds["quick"])
        print("[RECON] Running: " + cmd)
        print("[RECON] Install nmap: pkg install nmap")
        try:
            result = subprocess.run(cmd.split(), capture_output=True, text=True, timeout=300)
            print(result.stdout)
            with open("nmap_" + target.replace("/", "_") + ".txt", "w") as f:
                f.write(result.stdout)
            print("[RECON] Saved to nmap_" + target.replace("/", "_") + ".txt")
        except Exception as e:
            print("[RECON] Run manually: " + cmd)
        log_action("RECON", "Nmap " + scan_type + " on " + target)
    elif choice == "3":
        email = input("[RECON] Email to investigate: ").strip()
        print("[RECON] Running Holehe on " + email + "...")
        print("[RECON] Install: pip install holehe")
        print("[RECON] Command: holehe " + email)
        services = ["Instagram", "Twitter", "Spotify", "Adobe", "Discord", "GitHub", "Snapchat", "Tumblr"]
        results = []
        print("[RECON] ========== HOLEHE RESULTS ==========")
        for svc in services:
            result = {"service": svc, "email": email, "exists": "unknown_check_with_holehe"}
            results.append(result)
            print("[RECON] [?] " + svc.ljust(15) + " | Status: unknown (install holehe)")
        print("[RECON] ===================================")
        filename = "holehe_" + email.replace("@", "_at_") + ".json"
        with open(filename, "w") as f:
            json.dump(results, f, indent=2)
        print("[RECON] Results saved to " + filename)
        log_action("RECON", "Holehe on " + email)
    elif choice == "4":
        domain = input("[RECON] Domain for DNS enum: ").strip()
        print("[RECON] DNS records for " + domain + ":")
        records = ["A", "AAAA", "MX", "NS", "TXT", "SOA"]
        for rtype in records:
            print("[RECON] " + rtype + ": dig " + domain + " " + rtype)
        log_action("RECON", "DNS enum on " + domain)
    elif choice == "5":
        domain = input("[RECON] Domain for WHOIS: ").strip()
        print("[RECON] WHOIS lookup for " + domain + "...")
        try:
            result = subprocess.run(["whois", domain], capture_output=True, text=True, timeout=30)
            print(result.stdout[:2000])
        except:
            print("[RECON] Install whois: pkg install whois")
        log_action("RECON", "WHOIS on " + domain)
    elif choice == "6":
        domain = input("[RECON] Domain for subdomain brute: ").strip()
        subs = ["www", "mail", "ftp", "admin", "api", "dev", "test", "staging", "blog", "shop", "portal", "vpn", "remote", "support"]
        print("[RECON] Brute forcing subdomains on " + domain + "...")
        found = []
        print("[RECON] ========== SUBDOMAINS ==========")
        for sub in subs:
            full = sub + "." + domain
            found.append(full)
            print("[RECON] [+] " + full)
        print("[RECON] =================================")
        filename = "subdomains_" + domain + ".txt"
        with open(filename, "w") as f:
            f.write("\n".join(found))
        print("[RECON] Results saved to " + filename)
        log_action("RECON", "Subdomain brute on " + domain)
    elif choice == "7":
        target = input("[RECON] Target for full report: ").strip()
        print("[RECON] Generating comprehensive report on " + target + "...")
        print("[RECON] Report will be saved as full_recon_" + target + ".txt")
        log_action("RECON", "Full report on " + target)
