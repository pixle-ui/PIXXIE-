#!/usr/bin/env python3
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "core"))
from auth import auth_required
from utils import log_action

@auth_required
def run_crasher():
    print("""
    ╔═══════════════════════════════════════════════════════╗
    ║      SOCIAL MEDIA CRASHER MODULE                      ║
    ╚═══════════════════════════════════════════════════════╝
    """)
    print("[1] Instagram DM Spammer")
    print("[2] WhatsApp Message Bomber")
    print("[3] Facebook Message Flood")
    print("[4] Account Lockout")
    print("[5] Session Token Killer")
    print("[6] Notification Spam")
    choice = input("\n[CRASHER] Select: ").strip()
    if choice == "1":
        target = input("[CRASHER] Instagram username: ").strip()
        msg = input("[CRASHER] Message: ").strip()
        count = int(input("[CRASHER] Count (default 1000): ").strip() or "1000")
        print("[CRASHER] Spamming " + target + " with " + str(count) + " DMs...")
        for i in range(count):
            print("    [SPAM " + str(i+1) + "/" + str(count) + "] -> " + target + ": " + msg[:30])
            time.sleep(0.2)
        log_action("CRASHER", "IG spam " + str(count) + " to " + target)
    elif choice == "2":
        num = input("[CRASHER] WhatsApp number (+country): ").strip()
        msg = input("[CRASHER] Message: ").strip()
        count = int(input("[CRASHER] Count (default 500): ").strip() or "500")
        print("[CRASHER] Bombing " + num + "...")
        wa_url = "https://wa.me/" + num + "?text=" + msg
        print("[CRASHER] adb shell am start -a android.intent.action.VIEW -d " + repr(wa_url))
        for i in range(count):
            print("    [BOMB " + str(i+1) + "/" + str(count) + "] WA -> " + num)
        log_action("CRASHER", "WA bomb " + str(count) + " to " + num)
    elif choice == "3":
        target = input("[CRASHER] Facebook URL: ").strip()
        count = int(input("[CRASHER] Count (default 500): ").strip() or "500")
        for i in range(count):
            print("    [FLOOD " + str(i+1) + "/" + str(count) + "] -> FB")
            time.sleep(0.1)
        log_action("CRASHER", "FB flood " + str(count) + " to " + target)
    elif choice == "4":
        target = input("[CRASHER] Username/email: ").strip()
        plat = input("[CRASHER] Platform (ig/fb/tw/wa): ").strip()
        print("[CRASHER] Lockout attack on " + target + " (" + plat + ")...")
        for i in range(50):
            print("    [LOCKOUT " + str(i+1) + "/50] Wrong password")
            time.sleep(1)
        log_action("CRASHER", "Lockout on " + target + "@" + plat)
    elif choice == "5":
        token = input("[CRASHER] Token to kill: ").strip()
        print("[CRASHER] Token " + token + " killed.")
        log_action("CRASHER", "Token killed")
    elif choice == "6":
        target = input("[CRASHER] Target: ").strip()
        count = int(input("[CRASHER] Notifications: ").strip() or "100")
        for i in range(count):
            print("    [NOTIFY " + str(i+1) + "/" + str(count) + "] Ping!")
        log_action("CRASHER", "Notify spam " + str(count) + " to " + target)
