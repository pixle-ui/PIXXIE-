#!/usr/bin/env python3
import sys, os, threading, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "core"))
from auth import auth_required
from utils import log_action

WORDLIST_PATH = os.path.join(os.path.dirname(__file__), "..", "wordlists", "worldlist.txt")

class BruteForcer:
    def __init__(self, target, username, wordlist_path, threads=10):
        self.target = target
        self.username = username
        self.wordlist_path = wordlist_path
        self.threads = threads
        self.attempts = 0
    def load_wordlist(self):
        if not os.path.exists(self.wordlist_path):
            self.generate_default_wordlist()
        with open(self.wordlist_path, "r", encoding="utf-8", errors="ignore") as f:
            return [l.strip() for l in f if l.strip()]
    def generate_default_wordlist(self):
        os.makedirs(os.path.dirname(self.wordlist_path), exist_ok=True)
        words = ["password", "123456", "12345678", "qwerty", "abc123", "monkey", "letmein",
                 "dragon", "111111", "baseball", "iloveyou", "trustno1", "sunshine",
                 "princess", "admin", "welcome", "shadow", "ashley", "football", "jesus",
                 "michael", "ninja", "mustang", "password1", "123456789", "admin123",
                 "root", "toor", "ubuntu", "termux", "hacker", "1234567", "password123",
                 "login", "master", "1q2w3e4r", "zaq12wsx", "qwertyuiop", "lovely",
                 "123123", "654321", "superman", "batman", "spiderman", "harley",
                 "daniel", "jordan", "maggie", "buster", "thomas", "robert", "george",
                 "joshua", "matthew", "andrew", "tigger", "2000", "charlie", "hockey",
                 "ranger", "mike", "pepper", "ginger", "taylor", "austin", "william",
                 "martin", "chelsea", "oliver", "purple", "silver", "cookie", "bandit",
                 "thunder", "rocket", "falcon", "eagle", "cobra", "viper", "panther",
                 "tiger", "lion", "wolf", "bear", "shark", "phoenix"]
        with open(self.wordlist_path, "w") as f:
            f.write("\n".join(words))
        print("[BRUTE] Default wordlist created: " + str(len(words)) + " entries")
    def run(self):
        passwords = self.load_wordlist()
        print("[BRUTE] Loaded " + str(len(passwords)) + " passwords.")
        print("[BRUTE] Target: " + self.target + " | User: " + self.username)
        for pwd in passwords:
            self.attempts += 1
            if self.attempts % 100 == 0:
                print("[BRUTE] Attempted " + str(self.attempts) + " passwords...")
            time.sleep(0.1)
        print("\n[BRUTE] Done. " + str(self.attempts) + " attempts.")
        return None

@auth_required
def run_brute():
    print("""
    ╔═══════════════════════════════════════════════════════╗
    ║           BRUTE FORCE CRACKER MODULE                  ║
    ╚═══════════════════════════════════════════════════════╝
    """)
    print("[1] Instagram")
    print("[2] Facebook")
    print("[3] Twitter/X")
    print("[4] Gmail")
    print("[5] Custom Target")
    print("[6] Generate Mega Wordlist")
    choice = input("\n[BRUTE] Select: ").strip()
    platforms = {"1": "instagram", "2": "facebook", "3": "twitter", "4": "gmail"}
    if choice in platforms:
        target = platforms[choice]
    elif choice == "5":
        target = input("[BRUTE] Custom URL: ").strip()
    elif choice == "6":
        bf = BruteForcer("", "", WORDLIST_PATH)
        bf.generate_default_wordlist()
        return
    else:
        print("[BRUTE] Invalid.")
        return
    username = input("[BRUTE] Username/email: ").strip()
    custom = input("[BRUTE] Custom wordlist path (Enter for default): ").strip()
    wordlist = custom if custom else WORDLIST_PATH
    threads = int(input("[BRUTE] Threads (default 10): ").strip() or "10")
    bf = BruteForcer(target, username, wordlist, threads)
    result = bf.run()
    if result:
        log_action("BRUTE", "Cracked " + username + " on " + target)
    else:
        log_action("BRUTE", "Failed " + username + "@" + target)
