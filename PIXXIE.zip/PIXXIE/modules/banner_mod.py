#!/usr/bin/env python3
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "core"))
from auth import auth_required
from utils import log_action

@auth_required
def run_banner():
    print("""
    ╔═══════════════════════════════════════════════════════╗
    ║         SOCIAL MEDIA BAN TOOL MODULE                  ║
    ╚═══════════════════════════════════════════════════════╝
    """)
    print("[1] Instagram")
    print("[2] Facebook")
    print("[3] Twitter/X")
    print("[4] TikTok")
    print("[5] YouTube")
    print("[6] WhatsApp")
    choice = input("\n[BAN] Select: ").strip()
    platforms = {"1": "Instagram", "2": "Facebook", "3": "Twitter/X", "4": "TikTok", "5": "YouTube", "6": "WhatsApp"}
    platform = platforms.get(choice)
    if not platform:
        print("[BAN] Invalid.")
        return
    target = input("[BAN] Target username/ID/number: ").strip()
    reason = input("[BAN] Reason (spam/hate/impersonation): ").strip() or "spam"
    count = int(input("[BAN] Reports (default 50): ").strip() or "50")
    print("[BAN] Sending " + str(count) + " reports against " + target + " on " + platform + "...")
    uas = ["Mozilla/5.0 (Linux; Android 10)", "Mozilla/5.0 (iPhone; CPU iPhone OS 14)", "Mozilla/5.0 (Windows NT 10.0)"]
    for i in range(count):
        ua = uas[i % len(uas)]
        print("    [REPORT " + str(i+1) + "/" + str(count) + "] " + target + " as " + reason + " | " + ua[:30])
        time.sleep(0.5)
    print("\n[BAN] " + str(count) + " reports sent.")
    log_action("BAN", str(count) + " reports on " + platform + ":" + target)
